interface Animal {
    void eat();
}
interface Dog extends Animal {          // an interface extends another interface
    void bark();
}

class Labrador implements Dog {         // must implement eat() AND bark()
    public void eat()  { System.out.println("Labrador eats kibble"); }
    public void bark() { System.out.println("Labrador barks: Woof!"); }
}

public class InterfaceInherit {
    public static void main(String[] args) {
        Labrador lab = new Labrador();
        Animal a = lab;                 // usable as Animal
        Dog d = lab;                    // and as Dog
        a.eat();
        d.bark();
    }
}
