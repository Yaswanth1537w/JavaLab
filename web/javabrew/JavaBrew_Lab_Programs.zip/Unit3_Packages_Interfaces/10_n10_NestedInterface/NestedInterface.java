class University {
    String name = "Siddhartha University";

    interface Department {                  // nested interface (implicitly static)
        void details();
    }
}

class CSE implements University.Department {
    public void details() { System.out.println("CSE: 240 seats, labs for Java & DBMS"); }
}
class ECE implements University.Department {
    public void details() { System.out.println("ECE: 180 seats, VLSI & embedded labs"); }
}

public class NestedInterface {
    public static void main(String[] args) {
        System.out.println(new University().name);
        University.Department[] depts = { new CSE(), new ECE() };
        for (University.Department d : depts) d.details();
    }
}
