import utilities.Calculator;

public class CalcApp {
    public static void main(String[] args) {
        System.out.println("12 + 30 = " + Calculator.add(12, 30));
        System.out.println("12 x 30 = " + Calculator.multiply(12, 30));
        System.out.println("Loaded from: " + System.getProperty("java.class.path"));
    }
}
