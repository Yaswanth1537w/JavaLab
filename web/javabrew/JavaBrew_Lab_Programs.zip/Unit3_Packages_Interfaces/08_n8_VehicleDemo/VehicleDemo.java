interface Vehicle { void start(); }

class Car implements Vehicle {
    public void start() { System.out.println("Car starts with a push button"); }
}
class Bike implements Vehicle {
    public void start() { System.out.println("Bike starts with a kick"); }
}

public class VehicleDemo {
    public static void main(String[] args) {
        Vehicle v;
        v = new Car();  v.start();       // resolved at run time
        v = new Bike(); v.start();
    }
}
