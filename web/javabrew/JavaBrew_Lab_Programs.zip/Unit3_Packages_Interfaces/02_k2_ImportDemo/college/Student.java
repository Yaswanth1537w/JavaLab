package college;

public class Student {
    public String name;
    public Student(String name) { this.name = name; }
    public void show() { System.out.println("Student: " + name); }
}
