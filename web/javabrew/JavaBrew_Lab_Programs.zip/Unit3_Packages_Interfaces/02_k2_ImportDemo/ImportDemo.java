import college.Student;      // specific import: only Student
import college.*;            // wildcard: every public class in college (Faculty too)

public class ImportDemo {
    public static void main(String[] args) {
        Student s = new Student("Priya");
        Faculty f = new Faculty("Dr. Rao", "OOP through Java");
        college.Student full = new college.Student("Karthik");   // fully qualified name, no import needed
        s.show();
        f.show();
        full.show();
    }
}
