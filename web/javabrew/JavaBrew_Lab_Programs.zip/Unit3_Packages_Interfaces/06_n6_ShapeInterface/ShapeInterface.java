interface Shape {
    double area();                    // implicitly public abstract
}

class Circle implements Shape {
    double r;
    Circle(double r) { this.r = r; }
    public double area() { return Math.PI * r * r; }
}

class Rectangle implements Shape {
    double l, w;
    Rectangle(double l, double w) { this.l = l; this.w = w; }
    public double area() { return l * w; }
}

public class ShapeInterface {
    public static void main(String[] args) {
        Shape c = new Circle(3);
        Shape r = new Rectangle(4, 6);
        System.out.printf("Circle area    : %.2f%n", c.area());
        System.out.printf("Rectangle area : %.2f%n", r.area());
    }
}
