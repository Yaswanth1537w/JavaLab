package pack1;

public class SamePackage {
    public void test() {
        Base b = new Base();
        System.out.println("Same package      -> public " + b.pub + ", protected " + b.prot + ", default " + b.def + " (private hidden)");
        // b.priv  -> error: priv has private access in Base
    }
}
