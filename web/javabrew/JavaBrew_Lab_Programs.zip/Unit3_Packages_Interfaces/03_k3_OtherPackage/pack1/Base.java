package pack1;

public class Base {
    public    int pub  = 1;
    protected int prot = 2;
              int def  = 3;     // default (package-private)
    private   int priv = 4;

    public void fromSameClass() {
        System.out.println("Same class        -> public " + pub + ", protected " + prot + ", default " + def + ", private " + priv);
    }
}
