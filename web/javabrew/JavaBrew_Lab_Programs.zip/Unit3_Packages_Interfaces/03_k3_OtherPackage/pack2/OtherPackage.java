package pack2;

import pack1.Base;
import pack1.SamePackage;

class Child extends Base {                  // subclass in another package
    void test() {
        System.out.println("Subclass, pack2   -> public " + pub + ", protected " + prot + " (default & private hidden)");
    }
}

public class OtherPackage {
    public static void main(String[] args) {
        new Base().fromSameClass();
        new SamePackage().test();
        new Child().test();
        Base b = new Base();
        System.out.println("Non-subclass, pack2 -> public " + b.pub + " only");
        // b.prot, b.def, b.priv -> compile errors here
    }
}
