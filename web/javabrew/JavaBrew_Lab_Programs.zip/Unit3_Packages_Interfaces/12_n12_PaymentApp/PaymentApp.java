import java.util.Scanner;

interface Payment {
    void pay(double amount);
}

class CreditCardPayment implements Payment {
    public void pay(double amount) {
        double fee = amount * 0.02;
        System.out.printf("Paid Rs. %.2f by credit card (2%% fee: Rs. %.2f)%n", amount + fee, fee);
    }
}
class UPIPayment implements Payment {
    public void pay(double amount) {
        System.out.printf("Paid Rs. %.2f via UPI - no extra charge%n", amount);
    }
}
class NetBankingPayment implements Payment {
    public void pay(double amount) {
        System.out.printf("Paid Rs. %.2f via net banking (flat fee Rs. 10.00)%n", amount + 10);
    }
}

public class PaymentApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Credit card  2. UPI  3. Net banking");
        System.out.print("Choose a payment method: ");
        int choice = sc.nextInt();
        System.out.print("Enter amount: ");
        double amount = sc.nextDouble();

        Payment p;                                   // abstraction: we only know "Payment"
        switch (choice) {
            case 1:  p = new CreditCardPayment(); break;
            case 2:  p = new UPIPayment(); break;
            case 3:  p = new NetBankingPayment(); break;
            default: System.out.println("Invalid choice"); sc.close(); return;
        }
        p.pay(amount);                               // polymorphic call
        sc.close();
    }
}
