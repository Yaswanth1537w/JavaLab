interface Constants {
    int MAX_MARKS = 100;          // implicitly public static final
    double PI = 3.14159;
}

class Result implements Constants {
    void show(int marks) {
        System.out.println("Percentage: " + (marks * 100.0 / MAX_MARKS) + "%");   // inherited constant
    }
}

public class ConstantsDemo {
    public static void main(String[] args) {
        new Result().show(86);
        System.out.println("Constants.PI        = " + Constants.PI);            // via interface name
        System.out.println("Constants.MAX_MARKS = " + Constants.MAX_MARKS);
        // Constants.MAX_MARKS = 90;  // error: cannot assign a value to final variable MAX_MARKS
        System.out.println("Area of r = 2: " + Constants.PI * 2 * 2);
    }
}
