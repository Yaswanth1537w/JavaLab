import bank.*;

public class BankMain {
    public static void main(String[] args) {
        Customer c = new Customer("Adhi", "98xxxxxx21");
        Account a = new Account(40012345L, c, 2000);
        System.out.println("Customer: " + c);
        new Transaction(a, 3500).execute();
        new Transaction(a, -1200).execute();
        System.out.println(a.getOwner().getName() + "'s final balance: " + a.getBalance());
    }
}
