package bank;

public class Account {
    private final long number;
    private final Customer owner;
    private double balance;
    public Account(long number, Customer owner, double opening) {
        this.number = number; this.owner = owner; this.balance = opening;
    }
    public long getNumber()     { return number; }
    public double getBalance()  { return balance; }
    public Customer getOwner()  { return owner; }
    void apply(double amount)   { balance += amount; }   // package-private: only Transaction can call it
}
