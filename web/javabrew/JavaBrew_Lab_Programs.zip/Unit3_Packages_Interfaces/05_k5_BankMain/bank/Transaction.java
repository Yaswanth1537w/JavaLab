package bank;

public class Transaction {
    private final Account account;
    private final double amount;
    public Transaction(Account account, double amount) { this.account = account; this.amount = amount; }
    public void execute() {
        account.apply(amount);
        System.out.println((amount >= 0 ? "Credit " : "Debit ") + Math.abs(amount)
            + " on " + account.getNumber() + " -> balance " + account.getBalance());
    }
}
