package bank;

public class Customer {
    private final String name, phone;
    public Customer(String name, String phone) { this.name = name; this.phone = phone; }
    public String getName() { return name; }
    public String toString() { return name + " (" + phone + ")"; }
}
