package mypackage;

public class Student {                 // public: visible outside the package
    private String name;
    private int roll;

    public Student(String name, int roll) {
        this.name = name;
        this.roll = roll;
    }
    public void display() {
        System.out.println("Student " + roll + ": " + name);
    }
}
