import mypackage.Student;

public class UsePackage {
    public static void main(String[] args) {
        Student s = new Student("Adhi", 42);
        s.display();
    }
}
