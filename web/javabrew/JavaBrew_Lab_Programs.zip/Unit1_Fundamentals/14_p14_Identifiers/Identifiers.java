public class Identifiers {
    public static void main(String[] args) {
        // Valid identifiers: letters, digits, _ and $ ; must not start with a digit
        int marks = 90;
        int _count = 5;
        int $price = 250;
        int class2 = 3;          // contains a keyword but is not one
        String studentName = "Adhi";

        // Invalid - these would NOT compile:
        // int class = 1;        // 'class' is a reserved keyword
        // int 4a = 5;           // cannot start with a digit
        // int total-marks = 9;  // '-' is an operator, not allowed

        System.out.println(marks + " " + _count + " " + $price + " " + class2 + " " + studentName);
        System.out.println("Keywords like int, class, static are reserved:");
        System.out.println("the compiler uses them for syntax, so they cannot name variables.");
    }
}
