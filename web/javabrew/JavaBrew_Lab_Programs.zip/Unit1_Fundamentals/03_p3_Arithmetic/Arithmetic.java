public class Arithmetic {
    public static void main(String[] args) {
        int a = 65, b = 235;
        System.out.println("a + b = " + (a + b));
        System.out.println("a - b = " + (a - b));
        System.out.println("a * b = " + (a * b));
        System.out.println("a / b = " + (a / b) + "   (integer division drops the fraction)");
        System.out.println("a % b = " + (a % b));
    }
}
