public class BoolDemo {
    public static void main(String[] args) {
        boolean a = true, b = false;
        int marks = 72;

        System.out.println("a && b  = " + (a && b));
        System.out.println("a || b  = " + (a || b));
        System.out.println("!a      = " + (!a));
        System.out.println("a == b  = " + (a == b));
        boolean passed = marks >= 40;
        System.out.println("marks >= 40 -> passed = " + passed);
        System.out.println("distinction = " + (passed && marks >= 75));
    }
}
