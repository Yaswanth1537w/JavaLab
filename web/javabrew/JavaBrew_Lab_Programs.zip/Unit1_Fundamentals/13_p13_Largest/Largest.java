public class Largest {
    public static void main(String[] args) {
        int a = 5, b = 6;
        if (a > b)
            System.out.println(a + " is the largest");
        else if (b > a)
            System.out.println(b + " is the largest");
        else
            System.out.println("Both are equal: " + a);
    }
}
