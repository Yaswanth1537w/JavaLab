public class Variables {
    int a = 10;            // instance variable: one per object
    static int b = 20;     // static variable: one per class

    public static void main(String[] args) {
        int c = 30;        // local variable: lives in main's stack frame
        Variables obj = new Variables();
        System.out.println("Instance Variable: " + obj.a);
        System.out.println("Static Variable: " + b);
        System.out.println("Local Variable: " + c);
    }
}
