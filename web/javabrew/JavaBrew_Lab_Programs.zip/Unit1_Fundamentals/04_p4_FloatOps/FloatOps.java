public class FloatOps {
    public static void main(String[] args) {
        double a = 65.348, b = 45.204;
        System.out.println("a + b = " + (a + b));
        System.out.println("a - b = " + (a - b));
        System.out.println("a * b = " + (a * b));
        System.out.println("a / b = " + (a / b));
        System.out.println("a % b = " + (a % b));
        System.out.printf("a - b rounded to 3 places = %.3f%n", a - b);
    }
}
