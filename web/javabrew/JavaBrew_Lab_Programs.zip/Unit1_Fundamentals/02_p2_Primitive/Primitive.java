public class Primitive {
    public static void main(String[] args) {
        byte    a = 1;
        short   b = 2;
        int     c = 3;
        long    d = 4L;
        float   e = 5.5f;
        double  f = 6.25;
        char    g = 'A';
        boolean h = true;

        System.out.println("byte    a = " + a);
        System.out.println("short   b = " + b);
        System.out.println("int     c = " + c);
        System.out.println("long    d = " + d);
        System.out.println("float   e = " + e);
        System.out.println("double  f = " + f);
        System.out.println("char    g = " + g);
        System.out.println("boolean h = " + h);
    }
}
