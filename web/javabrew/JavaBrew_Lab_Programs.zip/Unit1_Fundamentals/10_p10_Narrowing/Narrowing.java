public class Narrowing {
    public static void main(String[] args) {
        double d = 10.6;
        int i = (int) d;             // fraction truncated
        int big = 300;
        byte b = (byte) big;         // keeps low 8 bits: 300 - 256
        long l = 70000L;
        short s = (short) l;         // keeps low 16 bits: 70000 - 65536
        float f = (float) 3.14159265358979;
        System.out.println("(int) 10.6     = " + i);
        System.out.println("(byte) 300     = " + b);
        System.out.println("(short) 70000  = " + s);
        System.out.println("(float) pi     = " + f);
    }
}
