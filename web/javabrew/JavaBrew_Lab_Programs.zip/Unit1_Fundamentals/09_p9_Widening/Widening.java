public class Widening {
    public static void main(String[] args) {
        byte   b = 42;
        short  s = b;      // byte  -> short
        int    i = s;      // short -> int
        long   l = i;      // int   -> long
        float  f = l;      // long  -> float
        double d = f;      // float -> double
        char   c = 'J';
        int    ci = c;     // char  -> int
        System.out.println("byte " + b + " -> short " + s + " -> int " + i);
        System.out.println("long " + l + " -> float " + f + " -> double " + d);
        System.out.println("char '" + c + "' -> int " + ci);
    }
}
