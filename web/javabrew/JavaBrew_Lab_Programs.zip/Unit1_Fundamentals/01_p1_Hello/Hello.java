// Basic structure: class -> main method -> statements
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, Java!");
    }
}
