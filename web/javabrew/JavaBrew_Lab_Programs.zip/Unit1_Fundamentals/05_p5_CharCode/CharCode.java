public class CharCode {
    public static void main(String[] args) {
        char c = 'A';
        int code = (int) c;
        System.out.println("Character : " + c);
        System.out.println("Unicode   : " + code);
        System.out.println("'a' is " + (int) 'a' + ", '0' is " + (int) '0');
    }
}
