public class CharInt {
    public static void main(String[] args) {
        char c = 'A';
        int code = (int) c;       // char -> int
        int d = 75;
        char e = (char) d;        // int  -> char
        System.out.println(c + " -> " + code);
        System.out.println(d + " -> " + e);
    }
}
