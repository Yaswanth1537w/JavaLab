import java.lang.ref.WeakReference;

class Cup {
    String label;
    Cup(String label) { this.label = label; }
}

public class GCDemo {
    public static void main(String[] args) throws InterruptedException {
        Cup c1 = new Cup("A"), c2 = new Cup("B"), c3 = new Cup("C");
        WeakReference<Cup> w1 = new WeakReference<>(c1);   // watches c1 without keeping it alive
        WeakReference<Cup> w2 = new WeakReference<>(c2);

        c1 = null;          // A is unreachable -> eligible
        c2 = null;          // B is unreachable -> eligible
        System.out.println("Cup C still referenced: " + c3.label);

        System.gc();        // a request, not a command
        Thread.sleep(100);
        int cleared = (w1.get() == null ? 1 : 0) + (w2.get() == null ? 1 : 0);
        System.out.println("Objects reclaimed after System.gc(): " + cleared + " of 2");
    }
}
