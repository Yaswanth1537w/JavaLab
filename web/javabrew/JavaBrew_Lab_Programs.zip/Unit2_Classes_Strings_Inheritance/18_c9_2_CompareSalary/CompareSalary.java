class Employee {
    String name; double salary;
    Employee(String name, double salary) { this.name = name; this.salary = salary; }
}

public class CompareSalary {
    static void higher(Employee a, Employee b) {
        if (a.salary > b.salary)      System.out.println(a.name + " earns more: Rs. " + a.salary);
        else if (b.salary > a.salary) System.out.println(b.name + " earns more: Rs. " + b.salary);
        else                          System.out.println("Both earn the same");
    }
    public static void main(String[] args) {
        Employee e1 = new Employee("Ravi", 48000);
        Employee e2 = new Employee("Meena", 56000);
        higher(e1, e2);
    }
}
