class Book {
    String title, author;
    double price;

    void show() { System.out.println(title + " by " + author + " - Rs. " + price); }
}

public class BookDemo {
    public static void main(String[] args) {
        Book b1 = new Book(), b2 = new Book(), b3 = new Book();
        b1.title = "Java: The Complete Reference"; b1.author = "Schildt"; b1.price = 899;
        b2.title = "Head First Java"; b2.author = "Sierra"; b2.price = 650;
        b3.title = "Programming with Java"; b3.author = "Balagurusamy"; b3.price = 540;
        b1.show(); b2.show(); b3.show();
    }
}
