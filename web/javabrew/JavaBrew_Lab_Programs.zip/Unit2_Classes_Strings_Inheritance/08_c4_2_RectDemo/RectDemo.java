class Rectangle {
    double length, width;
    double area()      { return length * width; }
    double perimeter() { return 2 * (length + width); }
    void display() {
        System.out.println("Area      = " + area());
        System.out.println("Perimeter = " + perimeter());
    }
}

public class RectDemo {
    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        r.length = 12; r.width = 5;
        r.display();
    }
}
