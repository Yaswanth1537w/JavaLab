class Vehicle {
    int speed = 80;
    void display() { System.out.println("Vehicle speed: " + speed + " km/h"); }
}

class Car extends Vehicle {
    int speed = 120;                  // hides Vehicle.speed
    String model = "Nexon";

    @Override
    void display() {
        super.display();              // superclass method
        System.out.println("Car model: " + model);
        System.out.println("Car speed: " + speed + ", Vehicle speed via super: " + super.speed);
    }
}

public class SuperVehicle {
    public static void main(String[] args) {
        new Car().display();
    }
}
