class Adder {
    int add(int a, int b)             { return a + b; }
    int add(int a, int b, int c)      { return a + b + c; }
    double add(double a, double b)    { return a + b; }
    String add(String a, String b)    { return a + b; }
}

public class OverloadAdd {
    public static void main(String[] args) {
        Adder ad = new Adder();
        System.out.println("add(2, 3)        = " + ad.add(2, 3));
        System.out.println("add(2, 3, 4)     = " + ad.add(2, 3, 4));
        System.out.println("add(2.5, 3.25)   = " + ad.add(2.5, 3.25));
        System.out.println("add(\"Ja\", \"va\")  = " + ad.add("Ja", "va"));
    }
}
