class Employee {
    int id;
    String name, dept;
    double salary;

    void display() {
        System.out.println(id + " | " + name + " | " + dept + " | Rs. " + salary);
    }
}

public class EmployeeInfo {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.id = 501; e.name = "Ravi"; e.dept = "R&D"; e.salary = 65000;
        e.display();
    }
}
