class BankAccount {
    String holder; double balance;
    BankAccount(String holder, double balance) { this.holder = holder; this.balance = balance; }

    BankAccount deposit(double amt) {
        balance += amt;
        return this;              // return the same, updated object
    }
}

public class ReturnAccount {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount("Adhi", 1000);
        BankAccount same = acc.deposit(500).deposit(250);    // chained calls
        System.out.println(same.holder + " balance: Rs. " + same.balance);
        System.out.println("Same object? " + (same == acc));
    }
}
