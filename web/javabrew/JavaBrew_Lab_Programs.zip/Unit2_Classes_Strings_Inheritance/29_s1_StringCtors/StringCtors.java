public class StringCtors {
    public static void main(String[] args) {
        String s1 = "Java";                           // literal -> string pool
        String s2 = new String();                     // empty string
        String s3 = new String("Java");               // new object on the heap
        char[] chars = {'B', 'r', 'e', 'w'};
        String s4 = new String(chars);                // from char array
        byte[] bytes = {74, 86, 77};
        String s5 = new String(bytes);                // from byte array (ASCII)
        String s6 = "Java";                           // same pooled literal as s1

        System.out.println("s1 = " + s1);
        System.out.println("s2 = \"" + s2 + "\" (length " + s2.length() + ")");
        System.out.println("s3 = " + s3);
        System.out.println("s4 = " + s4);
        System.out.println("s5 = " + s5);
        System.out.println("s1 == s6      : " + (s1 == s6) + "  (same pooled object)");
        System.out.println("s1 == s3      : " + (s1 == s3) + " (new creates a separate object)");
        System.out.println("s1.equals(s3) : " + s1.equals(s3) + "  (same characters)");
    }
}
