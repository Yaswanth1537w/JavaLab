class Person {
    String name; int age;
    void showPerson() { System.out.println("Name: " + name + ", Age: " + age); }
}

class Student extends Person {
    int roll; String branch;
    void showStudent() {
        showPerson();                                   // inherited method
        System.out.println("Roll: " + roll + ", Branch: " + branch);
    }
}

public class SingleInheritance {
    public static void main(String[] args) {
        Student s = new Student();
        s.name = "Adhi"; s.age = 19;                    // inherited fields
        s.roll = 42; s.branch = "CSE";
        s.showStudent();
    }
}
