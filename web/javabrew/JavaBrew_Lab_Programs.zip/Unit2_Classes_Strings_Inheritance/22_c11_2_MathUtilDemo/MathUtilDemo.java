class MathUtil {
    static int square(int n) { return n * n; }
    static int cube(int n)   { return n * n * n; }
    static long factorial(int n) {
        long f = 1;
        for (int i = 2; i <= n; i++) f *= i;
        return f;
    }
}

public class MathUtilDemo {
    public static void main(String[] args) {
        int n = 6;                                    // no object needed
        System.out.println("square(" + n + ")    = " + MathUtil.square(n));
        System.out.println("cube(" + n + ")      = " + MathUtil.cube(n));
        System.out.println("factorial(" + n + ") = " + MathUtil.factorial(n));
    }
}
