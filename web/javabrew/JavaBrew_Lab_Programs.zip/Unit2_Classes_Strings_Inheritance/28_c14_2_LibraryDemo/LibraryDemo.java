class Library {
    private String libName = "Central Library";
    private int issued = 0;

    class Book {
        String title;
        Book(String title) { this.title = title; }
        void issue() {
            issued++;                                     // modifies the outer object's private field
            System.out.println(title + " issued from " + libName + " (total issued: " + issued + ")");
        }
    }
}

public class LibraryDemo {
    public static void main(String[] args) {
        Library lib = new Library();
        Library.Book b1 = lib.new Book("Head First Java");
        Library.Book b2 = lib.new Book("Clean Code");
        b1.issue();
        b2.issue();
    }
}
