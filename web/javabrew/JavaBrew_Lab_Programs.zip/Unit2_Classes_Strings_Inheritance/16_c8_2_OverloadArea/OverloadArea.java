class Area {
    double area(double radius)           { return Math.PI * radius * radius; }   // circle
    double area(double length, double w) { return length * w; }                  // rectangle
    int area(int side)                   { return side * side; }                 // square
}

public class OverloadArea {
    public static void main(String[] args) {
        Area a = new Area();
        System.out.printf("Circle    (r = 7.0)    : %.2f%n", a.area(7.0));
        System.out.println("Rectangle (8.0 x 5.0)  : " + a.area(8.0, 5.0));
        System.out.println("Square    (side = 6)   : " + a.area(6));
    }
}
