class College {
    static String collegeName = "VR Siddhartha";

    static class Department {                 // static nested class
        String name; int intake;
        Department(String name, int intake) { this.name = name; this.intake = intake; }
        void show() {
            System.out.println(collegeName + " - " + name + " (intake " + intake + ")");
        }
    }
}

public class CollegeDemo {
    public static void main(String[] args) {
        College.Department d1 = new College.Department("CSE", 240);   // no College object needed
        College.Department d2 = new College.Department("ECE", 180);
        d1.show();
        d2.show();
    }
}
