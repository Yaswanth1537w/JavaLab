class Person {
    Person() { System.out.println("1. Person constructor"); }
}
class Student extends Person {
    Student() { System.out.println("2. Student constructor"); }       // implicit super()
}
class GraduateStudent extends Student {
    GraduateStudent() { System.out.println("3. GraduateStudent constructor"); }
}

public class CtorOrder {
    public static void main(String[] args) {
        new GraduateStudent();
    }
}
