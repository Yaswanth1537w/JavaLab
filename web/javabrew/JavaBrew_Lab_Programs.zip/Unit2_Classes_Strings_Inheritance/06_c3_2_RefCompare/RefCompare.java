class Employee {
    String name;
    Employee(String name) { this.name = name; }
}

public class RefCompare {
    public static void main(String[] args) {
        Employee e1 = new Employee("Ravi");
        Employee e2 = e1;                       // same object
        Employee e3 = new Employee("Ravi");     // equal data, different object
        System.out.println("e1 == e2 : " + (e1 == e2));
        System.out.println("e1 == e3 : " + (e1 == e3));
    }
}
