class Student {
    int roll;
    String name;

    Student() {                          // default (no-arg) constructor
        roll = 0;
        name = "Not assigned";
    }
    Student(int roll, String name) {     // parameterized constructor
        this.roll = roll;
        this.name = name;
    }
    void show() { System.out.println(roll + " : " + name); }
}

public class ConstructorDemo {
    public static void main(String[] args) {
        Student a = new Student();
        Student b = new Student(21, "Priya");
        a.show();
        b.show();
    }
}
