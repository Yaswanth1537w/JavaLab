class Employee {
    String name; double salary;
    String role = "Employee";
    Employee(String name, double salary) {
        this.name = name; this.salary = salary;
        System.out.println("Employee constructor called");
    }
    void display() { System.out.println("Name: " + name + ", Salary: " + salary); }
}

class Manager extends Employee {
    String role = "Manager";                  // hides Employee.role
    double bonus;
    Manager(String name, double salary, double bonus) {
        super(name, salary);                  // 1. super() -> superclass constructor
        this.bonus = bonus;
        System.out.println("Manager constructor called");
    }
    @Override void display() {
        super.display();                      // 2. super.method()
        System.out.println("Role: " + role + " (superclass role: " + super.role + ")");   // 3. super.variable
        System.out.println("Bonus: " + bonus + ", Total: " + (salary + bonus));
    }
}

public class SuperAll {
    public static void main(String[] args) {
        Manager m = new Manager("Anita", 90000, 15000);
        m.display();
    }
}
