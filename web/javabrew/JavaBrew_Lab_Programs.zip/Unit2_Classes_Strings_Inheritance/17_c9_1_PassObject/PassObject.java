class Student {
    String name; int roll;
    Student(String name, int roll) { this.name = name; this.roll = roll; }
}

public class PassObject {
    static void display(Student st) {          // st receives a copy of the reference
        System.out.println("Name: " + st.name + ", Roll: " + st.roll);
        st.roll = st.roll + 100;               // changes the SAME object
    }
    public static void main(String[] args) {
        Student s = new Student("Adhi", 7);
        display(s);
        System.out.println("After method, roll = " + s.roll);
    }
}
