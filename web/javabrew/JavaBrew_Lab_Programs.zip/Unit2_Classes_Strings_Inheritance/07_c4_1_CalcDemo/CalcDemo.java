class Calculator {
    double add(double a, double b) { return a + b; }
    double sub(double a, double b) { return a - b; }
    double mul(double a, double b) { return a * b; }
    double div(double a, double b) {
        if (b == 0) {
            System.out.println("Cannot divide by zero");
            return 0;
        }
        return a / b;
    }
}

public class CalcDemo {
    public static void main(String[] args) {
        Calculator c = new Calculator();
        double x = 24, y = 6;
        System.out.println("Add : " + c.add(x, y));
        System.out.println("Sub : " + c.sub(x, y));
        System.out.println("Mul : " + c.mul(x, y));
        System.out.println("Div : " + c.div(x, y));
    }
}
