class Student {
    String name = "Priya";
    int roll = 12;

    class Address {                       // inner (non-static) class
        String city = "Guntur";
        void show() {
            // an inner object can read the fields of its outer object
            System.out.println(roll + " " + name + " lives in " + city);
        }
    }
}

public class InnerAddress {
    public static void main(String[] args) {
        Student s = new Student();
        Student.Address a = s.new Address();   // needs an outer object
        a.show();
    }
}
