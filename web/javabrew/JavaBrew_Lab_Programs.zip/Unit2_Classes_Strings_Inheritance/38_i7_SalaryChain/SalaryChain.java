class Employee {
    double basic;
    Employee(double basic) { this.basic = basic; }
    double total() { return basic; }
}
class Developer extends Employee {
    double progAllowance;
    Developer(double basic, double pa) { super(basic); progAllowance = pa; }
    @Override double total() { return super.total() + progAllowance; }
}
class SeniorDeveloper extends Developer {
    double projectAllowance;
    SeniorDeveloper(double basic, double pa, double proj) { super(basic, pa); projectAllowance = proj; }
    @Override double total() { return super.total() + projectAllowance; }
}

public class SalaryChain {
    public static void main(String[] args) {
        SeniorDeveloper sd = new SeniorDeveloper(60000, 15000, 20000);
        System.out.println("Basic              : " + sd.basic);
        System.out.println("Programming allow. : " + sd.progAllowance);
        System.out.println("Project allowance  : " + sd.projectAllowance);
        System.out.println("Total salary       : " + sd.total());
    }
}
