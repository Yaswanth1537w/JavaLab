class Student {
    String name;
    double cgpa;
}

public class RefAssign {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "Adhi"; s1.cgpa = 8.2;
        Student s2 = s1;                 // copies the reference, not the object
        s2.cgpa = 9.1;                   // change through s2
        System.out.println("s1.cgpa = " + s1.cgpa);   // seen through s1
        System.out.println("s1 == s2 : " + (s1 == s2));
    }
}
