class Animal {
    void sound() { System.out.println("Some generic animal sound"); }
}
class Dog extends Animal {
    @Override void sound() { System.out.println("Dog: Woof woof"); }
}
class Cat extends Animal {
    @Override void sound() { System.out.println("Cat: Meow"); }
}

public class AnimalSounds {
    public static void main(String[] args) {
        new Animal().sound();
        new Dog().sound();
        new Cat().sound();
    }
}
