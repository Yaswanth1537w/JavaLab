class BankAccount {
    double balance;
    BankAccount(double balance) { this.balance = balance; }
    double calculateInterest() { return 0; }
}
class SavingsAccount extends BankAccount {
    SavingsAccount(double b) { super(b); }
    @Override double calculateInterest() { return balance * 0.04; }   // 4% p.a.
}
class CurrentAccount extends BankAccount {
    CurrentAccount(double b) { super(b); }
    @Override double calculateInterest() { return balance * 0.01; }   // 1% p.a.
}

public class InterestDispatch {
    public static void main(String[] args) {
        BankAccount[] accounts = { new SavingsAccount(50000), new CurrentAccount(50000) };
        for (BankAccount acc : accounts)
            System.out.println(acc.getClass().getSimpleName() + " interest: Rs. " + acc.calculateInterest());
    }
}
