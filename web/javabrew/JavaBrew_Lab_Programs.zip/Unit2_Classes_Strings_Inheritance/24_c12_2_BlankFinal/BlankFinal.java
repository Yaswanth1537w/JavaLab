class Employee {
    private static int next = 1001;
    final int empId;              // blank final: no value here
    String name;

    Employee(String name) {
        this.name = name;
        empId = next++;           // assigned exactly once, in the constructor
    }
}

public class BlankFinal {
    public static void main(String[] args) {
        Employee[] staff = { new Employee("Ravi"), new Employee("Meena"), new Employee("John") };
        for (Employee e : staff) System.out.println(e.empId + " -> " + e.name);
        // staff[0].empId = 5;    // error: cannot assign a value to final variable
    }
}
