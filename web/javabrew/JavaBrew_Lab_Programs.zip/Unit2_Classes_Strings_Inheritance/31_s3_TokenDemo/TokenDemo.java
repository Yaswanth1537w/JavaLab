import java.util.Scanner;
import java.util.StringTokenizer;

public class TokenDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String line = sc.nextLine();

        StringTokenizer st = new StringTokenizer(line);          // default: whitespace
        System.out.println("Total tokens: " + st.countTokens());
        while (st.hasMoreTokens()) System.out.println("  " + st.nextToken());

        System.out.print("Enter text to split: ");
        String text = sc.nextLine();
        System.out.print("Enter delimiter characters: ");
        String delim = sc.nextLine();
        StringTokenizer st2 = new StringTokenizer(text, delim);
        System.out.println("Total tokens: " + st2.countTokens());
        while (st2.hasMoreTokens()) System.out.println("  " + st2.nextToken());
        sc.close();
    }
}
