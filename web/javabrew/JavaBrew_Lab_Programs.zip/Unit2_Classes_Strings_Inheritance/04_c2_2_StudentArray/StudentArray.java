import java.util.Scanner;

class Student {
    int roll;
    String name, branch;
    Student(int roll, String name, String branch) {
        this.roll = roll; this.name = name; this.branch = branch;
    }
}

public class StudentArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Student[] list = new Student[5];          // array of 5 references (all null)
        for (int i = 0; i < list.length; i++) {
            System.out.print("Roll Name Branch for student " + (i + 1) + ": ");
            list[i] = new Student(sc.nextInt(), sc.next(), sc.next());
        }
        System.out.println();
        for (Student s : list)
            System.out.println(s.roll + "  " + s.name + "  " + s.branch);
        sc.close();
    }
}
