public class BufferDemo {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Java");
        System.out.println("Start    : " + sb + "  length=" + sb.length() + " capacity=" + sb.capacity());
        sb.append(" Programming");
        System.out.println("append   : " + sb);
        sb.insert(5, "OOP ");
        System.out.println("insert   : " + sb);
        sb.replace(0, 4, "Core Java");
        System.out.println("replace  : " + sb);
        sb.delete(10, 14);
        System.out.println("delete   : " + sb);
        sb.reverse();
        System.out.println("reverse  : " + sb);
        System.out.println("length=" + sb.length() + " capacity=" + sb.capacity());
    }
}
