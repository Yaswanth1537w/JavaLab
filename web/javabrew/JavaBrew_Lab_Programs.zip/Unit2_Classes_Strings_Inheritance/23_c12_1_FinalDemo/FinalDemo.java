final class Constants {                 // final class: cannot be extended
    static final double GST = 0.18;       // final variable: a constant
}

class Shop {
    final void printBill(double amt) {     // final method: cannot be overridden
        System.out.println("Amount " + amt + " + GST = " + amt * (1 + Constants.GST));
    }
}

class CoffeeShop extends Shop {
    // void printBill(double amt) { }    // error: cannot override final method
}

// class MyConstants extends Constants {} // error: cannot inherit from final class

public class FinalDemo {
    public static void main(String[] args) {
        new CoffeeShop().printBill(200);
        // Constants.GST = 0.12;           // error: cannot assign a value to final variable
        System.out.println("GST is fixed at " + Constants.GST);
    }
}
