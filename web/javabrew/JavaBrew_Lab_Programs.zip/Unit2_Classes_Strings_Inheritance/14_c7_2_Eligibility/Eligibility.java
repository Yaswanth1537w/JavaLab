class Box {
    int id;
    Box(int id) { this.id = id; System.out.println("Box " + id + " created"); }
    void show() { System.out.println("Box " + id + " in use"); }
}

public class Eligibility {
    public static void main(String[] args) {
        Box a = new Box(1);
        a = null;                     // 1. null assignment -> Box 1 eligible

        Box b = new Box(2);
        b = new Box(3);               // 2. reassignment   -> Box 2 eligible

        new Box(4).show();            // 3. anonymous object -> eligible right after use

        System.out.println("Boxes 1, 2 and 4 are now eligible for garbage collection");
        System.gc();
    }
}
