class Student {
    String name; String branch;
    Student(String name, String branch) { this.name = name; this.branch = branch; }
}

public class ReturnStudent {
    static Student admit(String name, String branch) {
        Student s = new Student(name, branch);   // created inside the method
        return s;                                // reference handed back
    }
    public static void main(String[] args) {
        Student x = admit("Sneha", "AI&DS");
        System.out.println("Admitted: " + x.name + " (" + x.branch + ")");
    }
}
