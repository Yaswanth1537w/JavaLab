class Student {
    String name;
    int age;

    void setWrong(String name, int age) {
        name = name;          // assigns the parameter to itself - field unchanged
        age = age;
    }
    void setRight(String name, int age) {
        this.name = name;     // this.name is the field, name is the parameter
        this.age = age;
    }
}

public class ThisDemo {
    public static void main(String[] args) {
        Student s = new Student();
        s.setWrong("Adhi", 19);
        System.out.println("Without this: " + s.name + ", " + s.age);
        s.setRight("Adhi", 19);
        System.out.println("With this   : " + s.name + ", " + s.age);
    }
}
