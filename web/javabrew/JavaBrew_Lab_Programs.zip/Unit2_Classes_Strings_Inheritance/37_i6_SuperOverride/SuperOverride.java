class Employee {
    String name = "Ravi"; int id = 301;
    void display() {
        System.out.println("Employee: " + name + " (ID " + id + ")");
    }
}
class Manager extends Employee {
    String team = "Payments"; int reports = 8;
    @Override void display() {
        super.display();                      // reuse, don't repeat
        System.out.println("Manages " + team + " team with " + reports + " reports");
    }
}

public class SuperOverride {
    public static void main(String[] args) {
        Employee e = new Manager();
        e.display();
    }
}
