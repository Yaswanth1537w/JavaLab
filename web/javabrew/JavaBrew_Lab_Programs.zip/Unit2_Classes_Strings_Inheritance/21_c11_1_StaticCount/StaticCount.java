class Student {
    static int count = 0;       // one copy shared by every Student
    String name;
    Student(String name) {
        this.name = name;
        count++;
    }
}

public class StaticCount {
    public static void main(String[] args) {
        new Student("Adhi");
        new Student("Priya");
        new Student("Rahul");
        System.out.println("Students created: " + Student.count);
    }
}
