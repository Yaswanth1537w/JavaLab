class Student {
    int roll; String name; String branch;

    Student() {
        this(0, "Guest");
        System.out.println("3. no-arg constructor finished");
    }
    Student(int roll, String name) {
        this(roll, name, "CSE");
        System.out.println("2. two-arg constructor finished");
    }
    Student(int roll, String name, String branch) {
        this.roll = roll; this.name = name; this.branch = branch;
        System.out.println("1. three-arg constructor finished");
    }
}

public class ChainDemo {
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.roll + " " + s.name + " " + s.branch);
    }
}
