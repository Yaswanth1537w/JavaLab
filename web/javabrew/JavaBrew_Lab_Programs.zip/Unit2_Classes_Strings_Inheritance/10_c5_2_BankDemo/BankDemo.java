class BankAccount {
    long accNo;
    String holder;
    double balance;

    BankAccount() { this(0, "Unknown", 0); }
    BankAccount(long accNo, String holder) { this(accNo, holder, 500); }  // min balance
    BankAccount(long accNo, String holder, double balance) {
        this.accNo = accNo; this.holder = holder; this.balance = balance;
    }
    void show() { System.out.println(accNo + " " + holder + " Rs. " + balance); }
}

public class BankDemo {
    public static void main(String[] args) {
        new BankAccount().show();
        new BankAccount(1001, "Adhi").show();
        new BankAccount(1002, "Sneha", 25000).show();
    }
}
