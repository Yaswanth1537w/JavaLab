class Employee {
    String name;
    Address addr;

    static class Address {
        String city, pin;
        Address(String city, String pin) { this.city = city; this.pin = pin; }
    }

    Employee(String name, Address addr) { this.name = name; this.addr = addr; }
    void show() { System.out.println(name + ", " + addr.city + " - " + addr.pin); }
}

public class EmployeeAddress {
    public static void main(String[] args) {
        Employee.Address a = new Employee.Address("Vijayawada", "520007");
        Employee e = new Employee("Ravi", a);
        e.show();
    }
}
