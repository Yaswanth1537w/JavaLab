class Person {
    String name = "Sneha"; int age = 34;
}

class Employee extends Person {
    int empId = 7021; double salary = 92000;
}

class Manager extends Employee {
    String department = "Engineering";
    void show() {
        System.out.println("Name       : " + name + " (" + age + ")");  // from Person
        System.out.println("Emp ID     : " + empId);                    // from Employee
        System.out.println("Salary     : " + salary);
        System.out.println("Department : " + department);               // own
    }
}

public class Multilevel {
    public static void main(String[] args) {
        new Manager().show();
    }
}
