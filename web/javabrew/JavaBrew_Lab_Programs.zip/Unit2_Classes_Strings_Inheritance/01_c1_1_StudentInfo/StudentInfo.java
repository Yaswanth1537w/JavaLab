class Student {
    int rollNo;
    String name, branch;
    double cgpa;

    void display() {
        System.out.println("Roll No : " + rollNo);
        System.out.println("Name    : " + name);
        System.out.println("Branch  : " + branch);
        System.out.println("CGPA    : " + cgpa);
    }
}

public class StudentInfo {
    public static void main(String[] args) {
        Student s = new Student();
        s.rollNo = 101;
        s.name = "Adhi";
        s.branch = "CSE";
        s.cgpa = 8.9;
        s.display();
    }
}
