class BankAccount {
    long accNo; double balance;
    BankAccount(long accNo, double balance) { this.accNo = accNo; this.balance = balance; }
    void deposit(double amt) { balance += amt; System.out.println(accNo + ": deposited " + amt + ", balance " + balance); }
    void withdraw(double amt) {
        if (amt <= balance) { balance -= amt; System.out.println(accNo + ": withdrew " + amt + ", balance " + balance); }
        else System.out.println(accNo + ": insufficient funds");
    }
    double interest() { return 0; }
}

class SavingsAccount extends BankAccount {
    static final double MIN_BALANCE = 1000;
    SavingsAccount(long n, double b) { super(n, b); }
    @Override void withdraw(double amt) {                 // keeps a minimum balance
        if (balance - amt < MIN_BALANCE) System.out.println(accNo + ": must keep minimum balance " + MIN_BALANCE);
        else super.withdraw(amt);
    }
    @Override double interest() { return balance * 0.04; }
}

class CurrentAccount extends BankAccount {
    double overdraft = 5000;
    CurrentAccount(long n, double b) { super(n, b); }
    @Override void withdraw(double amt) {                 // allows overdraft
        if (amt <= balance + overdraft) { balance -= amt; System.out.println(accNo + ": withdrew " + amt + ", balance " + balance); }
        else System.out.println(accNo + ": overdraft limit exceeded");
    }
}

public class BankingApp {
    public static void main(String[] args) {
        BankAccount s = new SavingsAccount(1001, 5000);
        BankAccount c = new CurrentAccount(2001, 2000);
        s.deposit(1500);
        s.withdraw(6000);
        s.withdraw(2000);
        c.withdraw(6000);
        System.out.println("Savings interest: " + s.interest());
        System.out.println("Current interest: " + c.interest());
    }
}
