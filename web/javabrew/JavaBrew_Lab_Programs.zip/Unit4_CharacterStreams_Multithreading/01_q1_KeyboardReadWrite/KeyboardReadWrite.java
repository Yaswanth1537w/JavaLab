import java.io.*;

class KeyboardReadWrite {
    public static void main(String[] args) throws IOException {
        Reader r = new InputStreamReader(System.in);
        Writer w = new OutputStreamWriter(System.out);

        System.out.println("Enter text (press Enter to stop):");

        int ch;
        while ((ch = r.read()) != '\n' && ch != -1) {
            w.write(ch);
        }

        w.flush();
        w.close();
    }
}
