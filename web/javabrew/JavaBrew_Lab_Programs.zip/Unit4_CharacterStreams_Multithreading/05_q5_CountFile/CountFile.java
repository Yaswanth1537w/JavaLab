import java.io.*;

class CountFile {
    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("input.txt");

        int chars = 0, words = 0, lines = 0;
        boolean inWord = false;
        int ch, last = -1;

        while ((ch = fr.read()) != -1) {
            chars++;
            if (ch == '\n') lines++;

            if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r') {
                inWord = false;            // a separator ends the current word
            } else if (!inWord) {
                inWord = true;             // first letter of a new word
                words++;
            }
            last = ch;
        }

        if (chars > 0 && last != '\n') lines++;   // count the final line only once

        fr.close();

        System.out.println("Characters: " + chars);
        System.out.println("Words: " + words);
        System.out.println("Lines: " + lines);
    }
}
