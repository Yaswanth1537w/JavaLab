import java.io.*;

class WriteFile {
    public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("output.txt");

        fw.write("Welcome to Java Character Streams");

        fw.close();
        System.out.println("Data written successfully");
    }
}
