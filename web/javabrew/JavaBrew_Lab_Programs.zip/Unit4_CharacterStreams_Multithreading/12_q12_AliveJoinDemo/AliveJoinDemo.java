class MyThread extends Thread {
    String name;

    MyThread(String name) {
        this.name = name;
    }

    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(name + " : " + i);
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class AliveJoinDemo {
    public static void main(String[] args) throws InterruptedException {
        MyThread t1 = new MyThread("Thread 1");
        MyThread t2 = new MyThread("Thread 2");
        MyThread t3 = new MyThread("Thread 3");

        t1.start();
        System.out.println("t1 alive: " + t1.isAlive());
        t1.join();    // wait for t1 to finish

        t2.start();
        System.out.println("t2 alive: " + t2.isAlive());
        t2.join();    // wait for t2 to finish

        t3.start();
        System.out.println("t3 alive: " + t3.isAlive());
        t3.join();    // wait for t3 to finish

        System.out.println("t1 alive: " + t1.isAlive());
        System.out.println("t2 alive: " + t2.isAlive());
        System.out.println("t3 alive: " + t3.isAlive());
        System.out.println("All threads finished");
    }
}
