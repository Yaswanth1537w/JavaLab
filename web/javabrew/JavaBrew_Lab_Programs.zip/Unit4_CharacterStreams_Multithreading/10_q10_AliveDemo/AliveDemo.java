class MyThread extends Thread {
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println("Child: " + i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class AliveDemo {
    public static void main(String[] args) throws InterruptedException {
        MyThread t = new MyThread();

        System.out.println("Before start: " + t.isAlive());

        t.start();
        System.out.println("After start: " + t.isAlive());

        Thread.sleep(2000);    // wait so the thread can finish
        System.out.println("After finishing: " + t.isAlive());
    }
}
